import heapq
import numpy as np
import random
import itertools

class AStarPlanner:
    def __init__(self):
        self.reset()
        
        self.MOVE_OFFSETS = [
            (1, 0),   # 0: 右 / Right
            (1, -1),  # 1: 右上 / Up-Right
            (0, -1),  # 2: 上 / Up
            (-1, -1), # 3: 左上 / Up-Left
            (-1, 0),  # 4: 左 / Left
            (-1, 1),  # 5: 左下 / Down-Left
            (0, 1),   # 6: 下 / Down
            (1, 1)    # 7: 右下 / Down-Right
        ]

    def reset(self):
        # 128x128全局地图，默认全为1（可通行） / 128x128 global map
        self.global_grid = np.ones((128, 128), dtype=np.int8)
        self.stuck_count = 0
        self.last_pos = None
        
        # DP Variables
        self.dp_built = False
        self.V_table = {}
        self.station_config_ids = []
        self.station_positions = []
        self.W_pos = None
        self.MAX_P = 3

    def _build_policy_table(self, organs):
        # 提取仓库与企鹅驿站 / Extract Warehouse and Express Stations
        w_organs = [o for o in organs if o.get("sub_type") == 1]
        if not w_organs:
            return
        self.W_pos = w_organs[0]['pos']
        
        stations = [o for o in organs if o.get("sub_type") == 3]
        if not stations:
            return
            
        # 过滤并分配唯一ID / Assign indices based on unique config_ids
        for s in stations:
            if s.get("config_id") not in self.station_config_ids:
                self.station_config_ids.append(s.get("config_id"))
                self.station_positions.append(s['pos'])
                
        N = len(self.station_config_ids)
        if N == 0:
            return
            
        self.MAX_P = min(3, N)
        
        # 生成距离矩阵 / Distance Matrix (Chebyshev)
        def dist(p1, p2):
            dx, dz = abs(p1['x'] - p2['x']), abs(p1['z'] - p2['z'])
            return abs(dx - dz) + 1.414 * min(dx, dz)
        dist_matrix = np.zeros((N+1, N+1))
        all_locs = [self.W_pos] + self.station_positions
        for i in range(N+1):
            for j in range(N+1):
                dist_matrix[i, j] = dist(all_locs[i], all_locs[j])
                
        # 初始化状态空间 / Init state space
        all_packages = tuple(range(1, N+1))
        states = []
        for k in range(self.MAX_P + 1):
            for p_tuple in itertools.combinations(all_packages, k):
                states.append(p_tuple)
                
        V = {(L, p_tuple): 0.0 for L in range(N+1) for p_tuple in states}
        
        # 预先计算盲盒抽取概率 / Pre-calc uniform draw probabilities
        draw_probs = {}
        for p_tuple in states:
            k = len(p_tuple)
            if k < self.MAX_P:
                needed = self.MAX_P - k
                avail = [x for x in all_packages if x not in p_tuple]
                draws = list(itertools.combinations(avail, needed))
                draw_probs[p_tuple] = draws
                
        # 价值迭代计算 (Relative Value Iteration)
        mu = 45.0  # 假设的初始步长消耗猜想 / Initial Expected Cost guess
        
        for _ in range(50):
            new_V = {}
            for L in range(N+1):
                for p_tuple in states:
                    k = len(p_tuple)
                    if L == 0:
                        if k < self.MAX_P:
                            draws = draw_probs[p_tuple]
                            avg = 0
                            for d in draws:
                                new_P = tuple(sorted(p_tuple + d))
                                avg += V[(0, new_P)]
                            new_V[(L, p_tuple)] = avg / len(draws)
                        else:
                            # Mandatory delivery from W
                            best_val = float('inf')
                            for p in p_tuple:
                                remaining_p = tuple(x for x in p_tuple if x != p)
                                val = dist_matrix[0, p] - mu + V[(p, remaining_p)]
                                if val < best_val: best_val = val
                            new_V[(L, p_tuple)] = best_val
                    else:
                        if k == 0:
                            # 没包裹必回拆仓 / empty payload -> MUST go to WH
                            new_V[(L, p_tuple)] = dist_matrix[L, 0] + V[(0, ())]
                        else:
                            best_val = float('inf')
                            # Opt 1: Go to Warehouse & Pick Blindboxes
                            if k < self.MAX_P:
                                val = dist_matrix[L, 0] + V[(0, p_tuple)]
                                if val < best_val: best_val = val
                            # Opt 2: Deliver items sequentially
                            for p in p_tuple:
                                remaining_p = tuple(x for x in p_tuple if x != p)
                                val = dist_matrix[L, p] - mu + V[(p, remaining_p)]
                                if val < best_val: best_val = val
                            new_V[(L, p_tuple)] = best_val
            
            diff = new_V[(0, ())] - V[(0, ())]
            mu += diff
            ref = new_V[(0, ())]
            for s in V:
                V[s] = new_V[s] - ref
                
        self.V_table = V
        self.dp_built = True

    def update_map(self, hx, hz, map_info):
        for dz in range(21):
            for dx in range(21):
                gx = hx - 10 + dx
                gz = hz - 10 + dz
                if 0 <= gx < 128 and 0 <= gz < 128:
                    try:
                        self.global_grid[gz, gx] = map_info[dz][dx]
                    except Exception:
                        pass
                        
    def heuristic(self, x1, z1, x2, z2):
        dx, dz = abs(x1 - x2), abs(z1 - z2)
        return abs(dx - dz) + 1.414 * min(dx, dz)

    def astar_search(self, start_x, start_z, target_x, target_z, legal_act, current_map):
        if start_x == target_x and start_z == target_z:
            return self.fallback_action(legal_act), 0

        open_set = []
        heapq.heappush(open_set, (0, start_x, start_z))
        came_from = {}
        g_score = {(start_x, start_z): 0}
        f_score = {(start_x, start_z): self.heuristic(start_x, start_z, target_x, target_z)}
        
        iterations = 0
        max_iterations = 1000 # 性能防卡死 / Prevent Lag
        
        while open_set and iterations < max_iterations:
            iterations += 1
            _, curr_x, curr_z = heapq.heappop(open_set)
            
            if curr_x == target_x and curr_z == target_z:
                break
                
            for act_idx, (dx, dz) in enumerate(self.MOVE_OFFSETS):
                nx, nz = curr_x + dx, curr_z + dz
                
                if 0 <= nx < 128 and 0 <= nz < 128:
                    if current_map[nz, nx] != 1 and not (nx == target_x and nz == target_z):
                        continue
                        
                    move_cost = 1.414 if dx != 0 and dz != 0 else 1.0
                    tg = g_score[(curr_x, curr_z)] + move_cost
                    if (nx, nz) not in g_score or tg < g_score[(nx, nz)]:
                        came_from[(nx, nz)] = (curr_x, curr_z, act_idx)
                        g_score[(nx, nz)] = tg
                        f = tg + self.heuristic(nx, nz, target_x, target_z)
                        heapq.heappush(open_set, (f, nx, nz))
                        
        if (target_x, target_z) not in came_from:
            return self.fallback_action(legal_act), float('inf')
            
        curr = (target_x, target_z)
        path = []
        while curr in came_from and curr != (start_x, start_z):
            prev_x, prev_z, act_idx = came_from[curr]
            path.append((act_idx, curr))
            curr = (prev_x, prev_z)
            
        if not path:
            return self.fallback_action(legal_act), float('inf')
            
        path.reverse()
        best_act = path[0][0]
        
        if legal_act and legal_act[best_act] == 0:
            return self.fallback_action(legal_act), float('inf')
            
        return best_act, g_score[(target_x, target_z)]
        
    def fallback_action(self, legal_act):
        if legal_act:
            valid_actions = [i for i, v in enumerate(legal_act[:8]) if v == 1]
            if valid_actions:
                return random.choice(valid_actions)
        return random.randint(0, 7)

    def get_action(self, env_obs):
        obs = env_obs.get("observation", {})
        frame_state = obs.get("frame_state", {})
        hero = frame_state.get("heroes", {})
        
        if "pos" not in hero:
            return 0
            
        hx, hz = hero["pos"]["x"], hero["pos"]["z"]
        battery = hero.get("battery", 100)
        packages = hero.get("packages", [])
        map_info = obs.get("map_info", [])
        organs = frame_state.get("organs", [])
        npcs = frame_state.get("npcs", [])
        legal_act = obs.get("legal_action", [1]*8)
        
        # 1. 确认建立MDP策略期待表 / Re-build DP if logic fresh
        if not self.dp_built:
            self._build_policy_table(organs)
            
        # 2. 地图更新与障碍施加 / Embed map tracking
        if map_info:
            self.update_map(hx, hz, map_info)
            
        current_map = self.global_grid.copy()
        for npc in npcs:
            npc_pos = npc.get("pos", {})
            if "x" in npc_pos and "z" in npc_pos:
                nx, nz = npc_pos["x"], npc_pos["z"]
                for dx in [-2, -1, 0, 1, 2]:
                    for dz in [-2, -1, 0, 1, 2]:
                        cx, cz = nx + dx, nz + dz
                        if 0 <= cx < 128 and 0 <= cz < 128:
                            current_map[cz, cx] = 0
                            
        # 预设防卡状态 / Anti-stuck checking
        if self.last_pos == (hx, hz):
            self.stuck_count += 1
        else:
            self.stuck_count = 0
            self.last_pos = (hx, hz)

        if self.stuck_count > 3:
            return self.fallback_action(legal_act)
            
        # 3. 规划并使用目标 DP 评估 / Active routing through target DP
        # 取电站安全坐标测算 / Acquire chargers for fallback routing
        chargers = [o['pos'] for o in organs if o.get("sub_type") in [1, 2]]
        if not chargers:
            chargers = [{'x': 64, 'z': 64}]
            
        def dist_to_charger(cx, cz):
            def _octile_dist(p1, p2):
                dx, dz = abs(p1['x'] - p2['x']), abs(p1['z'] - p2['z'])
                return abs(dx - dz) + 1.414 * min(dx, dz)
            return min([_octile_dist(c, {'x': cx, 'z': cz}) for c in chargers])
            
        def is_charger_func(t_pos):
            return any(c['x'] == t_pos['x'] and c['z'] == t_pos['z'] for c in chargers)

        # 4. DP Target Value Processing
        held_ids = set()
        for pkg_cfg in packages:
            if pkg_cfg in self.station_config_ids:
                held_ids.add(self.station_config_ids.index(pkg_cfg) + 1)
        p_tuple = tuple(sorted(held_ids))

        best_Q = float('inf')
        final_action = None
        
        # Inner Evaluator Func
        def evaluate_target(t_pos, Q_base):
            nonlocal best_Q, final_action
            
            # 使用包含阻挡区的A*跑出真实路长 / Eval real length with NPCObstacle Map
            act, act_dist = self.astar_search(hx, hz, t_pos['x'], t_pos['z'], legal_act, current_map)
            
            if act_dist == float('inf'):
                return # 彻底堵死或无解 / Unreachable
                
            # 电量存活测试验证 (Emergency test)
            if is_charger_func(t_pos):
                req_bat = act_dist + 5 
            else:
                ret_dist = dist_to_charger(t_pos['x'], t_pos['z'])
                req_bat = (act_dist + ret_dist) * 1.25
                
            if battery < req_bat:
                return # 太过冒险不安全，不予考虑 / Unsafe discard
                
            # 计算总期待价值 / Process minimum total Value metrics
            Q_total = act_dist + Q_base
            if Q_total < best_Q:
                best_Q = Q_total
                final_action = act

        if self.dp_built:
            # OPTION 1: 去抽卡测算 (如果兜里不满) / Go to warehouse 
            if len(p_tuple) < self.MAX_P:
                future_Q = self.V_table[(0, p_tuple)]
                evaluate_target(self.W_pos, future_Q)
                
            # OPTION 2: 去依次投递 / Go Deliver iteratively
            for p_id in p_tuple:
                s_pos = self.station_positions[p_id - 1]
                remaining = tuple(x for x in p_tuple if x != p_id)
                future_Q = self.V_table[(p_id, remaining)]
                evaluate_target(s_pos, future_Q)
                
        # 5. 保命急救 / Failsafe
        if final_action is None:
            # 如果所有的最优目标要么走不通，要么全会没电，触发保命机制强行回冲电站 
            chargers.sort(key=lambda c: max(abs(c['x'] - hx), abs(c['z'] - hz)))
            for c in chargers:
                act, act_dist = self.astar_search(hx, hz, c['x'], c['z'], legal_act, current_map)
                if act_dist != float('inf'):
                    return act
            return self.fallback_action(legal_act)
            
        return final_action
